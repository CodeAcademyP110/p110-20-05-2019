﻿using System;
using System.Text;
using PrimaryClasses;

namespace P110_ConsoleDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            #region ToString override
            //Person person = new Person();
            //person.Firstname = "Samir";
            //person.Lastname = "Dadash-zade";

            //Animal animal = new Animal();
            //animal.Name = "Mestan";
            //animal.Gene = "Bulldog";

            ////Console.WriteLine(person.ToString());
            //Console.WriteLine(person);
            //Console.WriteLine(animal);
            #endregion

            Person p = new Person();
            Console.WriteLine(Person.CountOfHumanity);

            p.Firstname = "Samir";
            p.Birthdate = new DateTime(1991, 11, 20);

            p.GetAge();
            Person.AddFiveYears(28);

            Person p2 = new Person();
            Console.WriteLine(Person.CountOfHumanity);

            p2.Firstname = "Medine";
            p.Birthdate = new DateTime(1999, 10, 10);

            p2.GetAge();
            Person.AddFiveYears(20);

            int a = Mathematics.Max(15, 29, 30);
            int b = Mathematics.Min(15, 29, 30);
        }
        
    }
     
    //custom type
    class Person
    {
        public string Firstname;
        public string Lastname;
        public DateTime Birthdate;
        public static int CountOfHumanity;

        public Person()
        {
            CountOfHumanity++;
        }

        public static int AddFiveYears(int age)
        {
            return age + 5;
        }

        public int GetAge()
        {
            return Mathematics.Max(DateTime.Now.Year - Birthdate.Year, 0);
        }

        public override string ToString()
        {
            return $"{Firstname} {Lastname}";
        }
    }

    class Animal
    {
        public string Name;
        public string Gene;

        public override string ToString()
        {
            return $"{Name} Gene: {Gene}";
        }
    }

    static class Mathematics
    {
        public static int Max(params int[] numbers)
        {
            int d = numbers[0];

            for (int i = 1; i < numbers.Length; i++)
            {
                if (numbers[i] > d) d = numbers[i];
            }

            return d;
        }

        public static int Min(params int[] numbers)
        {
            int d = numbers[0];

            for (int i = 1; i < numbers.Length; i++)
            {
                if (numbers[i] < d) d = numbers[i];
            }

            return d;
        }
    }
}

